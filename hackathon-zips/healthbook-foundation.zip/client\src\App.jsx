﻿/**
 * App Entry Point â€” Foundation
 */
import { BrowserRouter } from 'react-router-dom';

function App() {
    return (
        <BrowserRouter>
            <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-100 flex flex-col items-center justify-center">
                <div className="text-center space-y-4">
                    <div className="w-16 h-16 mx-auto bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <span className="text-white text-2xl">ðŸ¥</span>
                    </div>
                    <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-700 to-indigo-600 bg-clip-text text-transparent">
                        HealthBook V2
                    </h1>
                    <p className="text-gray-500 text-lg">Initializing application...</p>
                    <div className="w-48 h-1 mx-auto bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full animate-pulse" style={{width: '60%'}}></div>
                    </div>
                </div>
            </div>
        </BrowserRouter>
    );
}

export default App;
