﻿# HealthBook V2

> AI-Powered Healthcare Appointment Management System

## Quick Start

```bash
cd client && npm install && npm run dev
```

## Tech Stack
- **Frontend:** React 18 + Vite + TailwindCSS
- **Backend:** Supabase (PostgreSQL + Auth + Edge Functions)
- **AI/ML:** FastAPI + scikit-learn + Groq LLM
