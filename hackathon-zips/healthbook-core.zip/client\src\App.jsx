﻿/**
 * App Entry Point â€” Core Features
 *
 * Auth, public pages, dashboard.
 */
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ToastProvider } from '@/components/ui/Toast';
import { Toaster } from 'react-hot-toast';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

// Pages
import Landing from '@/pages/Landing';
import Dashboard from '@/pages/Dashboard';
import NotFound from '@/pages/NotFound';
import Doctors from '@/pages/Doctors';
import Departments from '@/pages/Departments';
import About from '@/pages/About';
import Settings from '@/pages/Settings';

// Auth pages
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import ForgotPasswordForm from '@/components/auth/ForgotPasswordForm';

// Error Boundary
import ErrorBoundary from '@/components/ErrorBoundary';

function App() {
    return (
        <ErrorBoundary>
            <BrowserRouter>
                <AuthProvider>
                    <ToastProvider>
                        <Routes>
                            {/* Public Routes */}
                            <Route path="/" element={<Landing />} />
                            <Route path="/login" element={<LoginForm />} />
                            <Route path="/register" element={<RegisterForm />} />
                            <Route path="/forgot-password" element={<ForgotPasswordForm />} />
                            <Route path="/doctors" element={<Doctors />} />
                            <Route path="/departments" element={<Departments />} />
                            <Route path="/about" element={<About />} />

                            {/* Protected Routes */}
                            <Route
                                path="/dashboard"
                                element={
                                    <ProtectedRoute>
                                        <Dashboard />
                                    </ProtectedRoute>
                                }
                            />
                            <Route
                                path="/settings"
                                element={
                                    <ProtectedRoute>
                                        <Settings />
                                    </ProtectedRoute>
                                }
                            />

                            {/* 404 */}
                            <Route path="*" element={<NotFound />} />
                        </Routes>

                        {/* React Hot Toast */}
                        <Toaster
                            position="top-right"
                            toastOptions={{
                                duration: 4000,
                                style: {
                                    background: '#fff',
                                    color: '#363636',
                                    padding: '16px',
                                    borderRadius: '12px',
                                    boxShadow: '0 10px 40px rgba(0, 0, 0, 0.12)',
                                },
                                success: {
                                    duration: 3000,
                                    style: {
                                        background: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
                                        color: '#fff',
                                    },
                                },
                                error: {
                                    duration: 5000,
                                    style: {
                                        background: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)',
                                        color: '#fff',
                                    },
                                },
                            }}
                        />
                    </ToastProvider>
                </AuthProvider>
            </BrowserRouter>
        </ErrorBoundary>
    );
}

export default App;
